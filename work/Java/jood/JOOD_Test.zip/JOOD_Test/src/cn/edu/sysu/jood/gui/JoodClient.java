package cn.edu.sysu.jood.gui;
/**
 * GUI Entry of Jood Application;
 */