package cn.edu.sysu.jood;

public class InitException extends Exception {
    private static final long serialVersionUID = -3811284360520107130L;
}
