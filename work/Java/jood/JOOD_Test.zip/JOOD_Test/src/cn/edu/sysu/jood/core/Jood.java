package cn.edu.sysu.jood.core;

public class Jood {
}